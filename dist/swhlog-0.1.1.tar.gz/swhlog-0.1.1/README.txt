this is intended to be installed with pip:
"pip install swhlog"

For details, check the project page:
http://github.com/swharden/swhlog